var num = document.querySelector('#numberInput');
var factBody = document.querySelector('#numFact');
var factText = document.querySelector('#numText');

var year = document.querySelector('#yearInput');
var yearfactBody = document.querySelector('#yearFact');
var yearfactText = document.querySelector('#yearText');

var date = document.querySelector('#dateInput');
var dateFactBody = document.querySelector('#dateFact');
var dateFactText = document.querySelector('#dateText');



num.addEventListener('input', getNumberFact);
year.addEventListener('keyup', getYearFact);
date.addEventListener('keyup', getDateFact);

function getNumberFact() {
	var number = num.value;

	var xhr = new XMLHttpRequest();
	xhr.open('get','http://numbersapi.com/'+number);
	xhr.onload = function(){
		if(this.status = 200 && number != ""){
			factBody.style.display = "block";
			factText.innerHTML = this.responseText;
		}
	}
	xhr.send();
}
function getYearFact() {
	var yearEntered = year.value;

	var xhr = new XMLHttpRequest();
	xhr.open('get','http://numbersapi.com/'+yearEntered+'/year'+'');
	xhr.onload = function(){
		if(this.status = 200 && yearEntered != ""){
			yearfactBody.style.display = "block";
			yearfactText.innerHTML = this.responseText;
		}
	}
	xhr.send();
}

function getDateFact() {
	
	dateEntered = date.value;
	var xhr = new XMLHttpRequest();
	xhr.open('get','http://numbersapi.com/'+dateEntered+'/date');
	xhr.onload = function(){
		if(this.status = 200 && dateEntered !=""){
			dateFactBody.style.display = "block";
			dateFactBody.innerHTML = this.responseText;
		}
	}
	xhr.send();
}